package dataflow;

public class DataflowException extends RuntimeException {

  public DataflowException(String msg) {
    super (msg);
  }
}