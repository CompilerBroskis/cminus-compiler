package x86codegen;

public class X86CodegenException extends RuntimeException{

  public X86CodegenException(String msg) {
    super (msg);
  }
}